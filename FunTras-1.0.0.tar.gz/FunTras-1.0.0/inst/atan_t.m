## Copyright (C) 2020 scyoc
## 
## This program is free software: you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see
## <https://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {} {@var{retval} =} tmo (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: scyoc <scyoc@LAPTOP-F1VIE4P9>
## Created: 2020-10-12

## entrada:
## X -> un numero real
## salida: arcotangente de X (arctan(X))
function retval = atan_t (X)
  if(abs(X) > 1)
    printf("Error, X para atan_t(X) debe ser estar en el rango [-1, 1]\n");
  else  
    tolerancia = 10^(-8);
    error = tolerancia + 1;
    base = 0;
    retval = 0;
    cont = 0;
    continuar = true;
    while(continuar)
      aux = (2*cont + 1);
      retval += (-1)^cont * (X^aux) * div_t(aux);
      cont ++;
      error = abs(retval - base);
      base = retval;
      if(error < tolerancia)
        continuar = false;
      elseif(cont > 10)
        printf("Iteraciones maximas alcanzadas en atan_t(X)\n");
        continuar = false;
      end
    end
  end  
endfunction
