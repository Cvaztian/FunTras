## Copyright (C) 2020 scyoc
## 
## This program is free software: you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see
## <https://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {} {@var{retval} =} tmo (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: scyoc <scyoc@LAPTOP-F1VIE4P9>
## Created: 2020-10-12

## entrada:
## X -> un numero mayor que 0
## A -> numero real, indice de la raiz
## salida: raiz de indice A de X (root_a(X))
function retval = root_t (X, A)
  continuar = true;
  if(X < 0)
    printf("Error, X debe ser igual o mayor a 0 en root_t(X,A)\n");
    continuar = false;
  elseif(A == 0)
    printf("Error, A debe ser diferente a 0 en root_t(X,A)\n");
    continuar = false;
  elseif(X == 0)
    retval = 0;
    continuar = false;  
  else
    tolerancia = 10^(-8);
    error = tolerancia + 1;
    cont = 0;  
    base = X*div_t(2);
    retval = 0;
    cont = 0;
    while(continuar)
      retval = base - (power_t(A, base) - X) * div_t(A*power_t(A-1, base));
      cont ++;
      error = abs((retval - base) * div_t(retval));
      base = retval;
      if(error < tolerancia)
        continuar = false;
      elseif(cont > 2500)
        printf("Iteraciones maximas alcanzadas en root_t(X,A)\n");
        continuar = false;
      end
    end
  end  
endfunction
