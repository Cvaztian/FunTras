## Copyright (C) 2020 scyoc
## 
## This program is free software: you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see
## <https://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {} {@var{retval} =} tmo (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: scyoc <scyoc@LAPTOP-F1VIE4P9>
## Created: 2020-10-12

## entradas:
## X -> numero real, exponente de la potencia
## A -> numero real, base de la potencia
## salida: A elevado a la X (A^X)
function retval = power_t (X, A)
  intX = round(X);
  notInt = intX - X;
  # No puede ser raiz de un negativo
  if((A < 0) && (notInt!=0))
    printf("Para la funcion power_t(X,A) si 'A' es menor que 0, 'X' debe ser un numero entero\n");
  # Si la base A < 0, es una funcion discreta
  else
    if(A<0)
      # Si X>=0 se multiplica X veces por si mismo
      if(X >= 0)
        retval = A^intX;
      # Si X<0 se multiplica X veces por si mismo y se calcula su inversion (1/A^X)
      else
        retval = div_t(A^intX);
      end
    # Si A es 0 A^X es 0, a menos que X sea 0, entonces el resultado es 1  
    elseif(A == 0)
      if(X == 0)
        retval = 1;
      else
        retval = 0;
      end
    # Se utiliza la propiedad A^X = e^(X * ln(A)) para calcular A^x
    else 
      retval = exp_t(X*ln_t(A));
    end
  end  
endfunction
