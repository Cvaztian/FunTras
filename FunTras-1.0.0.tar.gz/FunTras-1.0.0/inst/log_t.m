## Copyright (C) 2020 scyoc
## 
## This program is free software: you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see
## <https://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {} {@var{retval} =} tmo (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: scyoc <scyoc@LAPTOP-F1VIE4P9>
## Created: 2020-10-12

## entradas:
## X -> un numero real mayor que 0
## A -> numero real, base del logaritmo
## salida: logaritmo base A de X (log_a(X))
function retval = log_t (X, A)
  if(X <= 0)
    printf("Error, el argumento del logaritmo debe ser mayor a 0 en log_t(X)\n");
  elseif((A <= 0) || (A == 1))
    printf("Error, la base del logaritmo debe ser mayor a 0 y distinta de 1 en log_t(X)\n");
  else
    retval = (ln_t(X) * div_t(ln_t(A)));
  end  
endfunction
