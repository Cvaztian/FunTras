## Copyright (C) 2020 scyoc
## 
## This program is free software: you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see
## <https://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {} {@var{retval} =} tmo (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: scyoc <scyoc@LAPTOP-F1VIE4P9>
## Created: 2020-10-12

## entrada:
## X -> un numero real
## salida: seno hiperbolico de X (sen(X))
function retval = sinh_t (X)
  tolerancia = 10^(-8);
  base = 0;
  retval = 0;
  cont = 0;
  continuar = true;
  while(continuar)
    aux = (2*cont + 1);
    retval += ((X^aux)*div_t(factorial(aux)));
    error = abs(retval - base);
    base = retval;
    cont++;
    if(error < tolerancia)
      continuar = false;
    elseif(cont >= 2500)
      printf("Iteraciones maximas alcanzadas en sinh_t(X)\n");
      continuar = false;
    end  
  end  
endfunction
