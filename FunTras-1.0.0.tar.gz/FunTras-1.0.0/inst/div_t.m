## Copyright (C) 2020 scyoc
## 
## This program is free software: you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see
## <https://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {} {@var{retval} =} tmo (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: scyoc <scyoc@LAPTOP-F1VIE4P9>
## Created: 2020-10-12

## entrada:
## X -> un numero real
## salida: inversa de X (1/x )
function aprox = div_t(X)
  continuar = true;
  if(X == 0)
    printf("Error, la funcion div_t(x) necesita un X diferente de 0\n");
    continuar = false;
  else
    tolerancia = 10^(-8);
    error = tolerancia + 1;
    xAbs = abs(X);
    if(xAbs <= factorial(20))
      base = eps^2;
    elseif(xAbs <= factorial(40))
      base = eps^4;
    elseif(xAbs <= factorial(60))
      base = eps^8;
    elseif(xAbs <= factorial(80))
      base = eps^11;
    elseif(xAbs <= factorial(100))
      base = eps^15;
    else
      printf("Se ha excedido el numero maximo calculable, la magnitud de X debe ser menor o igual a 100! para div_t(X)\n");
      continuar = false;
    end
    cont = 0;
    while(continuar)
      aprox = base*(2-xAbs*base);
      error = abs((aprox - base)/aprox);
      base = aprox;
      cont++;
      if(error < tolerancia)
        continuar = false;
      elseif(cont > 2500)
        printf("Iteraciones maximas alcanzadas en div_t(X)\n");
        continuar = false
      end  
    end
    if(X <0)
      aprox = -1*aprox;
    end  
end











