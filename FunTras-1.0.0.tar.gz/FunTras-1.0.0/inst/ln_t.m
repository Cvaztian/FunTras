## Copyright (C) 2020 scyoc
## 
## This program is free software: you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see
## <https://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {} {@var{retval} =} tmo (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: scyoc <scyoc@LAPTOP-F1VIE4P9>
## Created: 2020-10-12

## entrada:
## X -> un numero real mayor que 0
## salida: logaritmo natural de X (ln(X))
function retval = ln_t (X)
  if(X <= 0)
    printf("Error, el argumento debe ser mayor a 0 en ln_t(X)\n");
  else
    tolerancia = 10^(-8);
    auxNeg = (X-1);
    auxPos = (X+1);
    sumatoria = 0;
    base = 0;
    retval = 0;
    cont = 0;
    continuar = true;
    while(continuar)
      sumatoria += (div_t((2*cont) + 1) * ((auxNeg * div_t(auxPos))^(2*cont)));
      retval = ((2*auxNeg)*div_t(auxPos))*sumatoria;
      error = abs(retval - base);
      base = retval;
      cont++;
      if(error < tolerancia)
        continuar = false;
      elseif(cont > 2500)
        printf("Iteraciones maximas alcanzadas en ln_t(X)\n");
        continuar = false;
      end  
    end
  end  
endfunction
